<?php
/*****************************************************************************
** This script is proivded by DMASOFTLAB RM.
** Modified by Syed Jahanzaib / https://aacable.wordpress.com / aacable@hotmail.com
** I am using KANNEL as GATEWAY with 20sec delay via this PHP PAGE
**        Name: sendsms (RM 4.1.x)
**    Function: This function is used to send SMS message to a mobile phone.
**      Inputs: $recp - Mobile number
**        $body - Message body
**        $errmsg - Pointer to error message returned by the gateway
**      Result: True if API succeeded or false
*****************************************************************************/
function sendsms($recp, $body, &$errmsg)
{
// enter your LOCAL HTTP SMS GATEWAY here

$api_user     = "kannel";
$api_password = "kannel";

// clean up HTML entities

$body = html_entity_decode($body, ENT_COMPAT, "UTF-8");


// implement your own SMS gateway here

$body = rawurlencode($body);
$ch = curl_init();
// change the IP and id password in the below line to match your local config. syed jahanzaib

curl_setopt($ch, CURLOPT_URL, "http://localhost:13013/cgi-bin/sendsms?user=$api_user&password=$api_password&to=$recp&text=$body");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Adding 20 seconds delay so that oru mobile SIM may not get blocked / syed jahanzaib
sleep(10);


$res = curl_exec($ch);
curl_close($ch);

// uncomment the following line to see the result from the SMS gateway

//  print $res;

// log result

if (substr($res, 0 , 4) == "ERR:")
$res_str = $res;
else
$res_str = "OK";

syslog(LOG_INFO, "[radiusmanager] Sending SMS with test 20 sec delay in each SMS added by zaib to Mobile No " . $recp . " (" . $res_str . ")");

// error has occured, return FALSE

if (substr($res, 0 , 4) == "ERR:")
{
$errmsg = $res;
return false;
}

// no error, return TRUE

return true;
}
?>

