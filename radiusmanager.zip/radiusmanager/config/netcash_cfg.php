<?php

  // Netcash credentials
  
  define('NETCASH_USERNAME', 'username');
  define('NETCASH_PASSWORD', 'password');
  define('NETCASH_PIN', '12345');
  define('TERMINAL_NUMBER', '12345');

  // other data

  define('NETCASH_EMAIL', 'info@mycompany.com');

?>
